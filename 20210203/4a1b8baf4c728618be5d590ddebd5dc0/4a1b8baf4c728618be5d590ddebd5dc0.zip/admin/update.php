<?php
/*
 * @Descripttion: 
 * @Author: 帅气的杜恒欧巴
 * @Date: 2020-12-22 17:43:01
 * @LastEditTime: 2020-12-23 18:52:20
 */
error_reporting(0);
header("Access-Control-Allow-Origin:*");
header('Content-type:application/json; charset=utf-8');

/* 
 *
 * 不允许上传的文件类型，需要屏蔽什么类型，就写什么类型的后缀，第一个 '' 不能删
 * 
  */
$not_allow_suffix = array('', '.exe', '.msc');

/* 
 *
 * 设置上传密码，默认密码为 123456
 * 
 * */
$password = "QQ123456";


if (strcmp($password, $_GET['password']) != 0) {
	msg(['code' => -1, 'msg' => '密码错误！']);
} else {
	$file = $_FILES['file'];
	if (is_uploaded_file($file['tmp_name'])) {

		$arr = pathinfo($file['name']);

		/* 文件后缀 */
		$ext_suffix = $arr['extension'] ? '.' . $arr['extension'] : '';

		if (in_array($ext_suffix, $not_allow_suffix)) msg(['code' => 0, 'msg' => '不允许的文件类型']);

		/* 生成文件地址 */
		$dir = createDir(0);
		$dir_output = createDir(1);
		$name = createName($arr['filename']);
		$new_filename = $dir . $name . $ext_suffix;

		if (move_uploaded_file($file['tmp_name'], $new_filename)) {
			msg(['code' => 1, 'msg' =>  '//' . $_SERVER['HTTP_HOST'] . '/?' . $dir_output . $name . $ext_suffix]);
		} else {
			msg(['code' => 0, 'msg' => '上传数据有误']);
		}
	} else {
		msg(['code' => 0, 'msg' => '上传数据有误']);
	}
}




function msg($data)
{
	exit(json_encode($data));
}

/* 生成目录 */
function createDir($type = 0)
{
	/* 根目录 */
	$root_dir = '../_uploads';

	/* 年份 */
	$year = date('Y', time());
	$year_dir = '';
	if (is_dir($root_dir . '/' . $year)) {
		$year_dir = $year;
	} else {
		mkdir($root_dir . '/' . $year, 0777, true);
		$year_dir = $year;
	}

	/* 月份 */
	$month = date('m', time());
	$month_dir = '';
	if (is_dir($root_dir . '/' . $year . '/' . $month)) {
		$month_dir = $month;
	} else {
		mkdir($root_dir . '/' . $year . '/' . $month, 0777, true);
		$month_dir = $month;
	}
	if ($type === 0) {
		return $root_dir . '/' . $year_dir . '/' . $month_dir . '/';
	} else {
		return $year_dir . '/' . $month_dir . '#';
	}
}

/* 生成随机名称 */
function createName($name)
{
	return $name . '_' . substr(md5(time() . rand(0, 100)), 5, 8);
}
