document.addEventListener("DOMContentLoaded",function(){
    document.body.addEventListener('touchstart',function(){});
    
    {
        
        let elHeaderTopSearchIcon = document.querySelector(".el-header__top-search-icon");
        let elHeaderSearch = document.querySelector(".el-header__search");
        let elModal = document.querySelector(".el-modal");
        elHeaderTopSearchIcon.addEventListener("click", function() {
            elHeaderTopSearchIcon.classList.toggle("active");
            elHeaderSearch.classList.toggle("active");
            elModal.classList.toggle("active");
            document.body.classList.toggle("disabled-scroll");
        });
        elModal.addEventListener("click", function() {
            elHeaderTopSearchIcon.classList.remove("active");
            elHeaderSearch.classList.remove("active");
            elModal.classList.remove("active");
            document.body.classList.remove("disabled-scroll");
        });
    }
    
    
    {
        let width = window.screen.width;
        let slidesPerView = 1;
        if(width <= 576) slidesPerView = 2.4;
        new Swiper('.swiper-container', {
            slidesPerView,
            centeredSlides: true,
            loop: true,
        });
    }
    
    {
        new LazyLoad('.lazyload');
    }
    
    {
    	let playList = document.querySelector('.el-play__list-head');
    	let activeTab = document.querySelector('.el-play__list-head .active');
    	activeTab && (playList.scrollLeft = activeTab.offsetLeft - playList.offsetWidth / 2 + activeTab.offsetWidth / 2 - 15);
    	let playPage = document.querySelector('.el-play__list-body .visible');
    	let activePage = document.querySelector('.el-play__list-body .visible .active');
    	playPage && (playPage.scrollTop = activePage.offsetTop - 5);
    }
})