/*
 * @Descripttion: 
 * @Author: 帅气的杜恒欧巴
 * @Date: 2020-12-14 08:53:06
 * @LastEditTime: 2020-12-14 10:04:11
 */
export const config = {
    domain: 'https://t.chuanhanzi.cn',                  // 网站如果开启了伪静态填写这个，并将下面注释掉。将域名换成你的
    // domain: 'https:/t.chuanhanzi.cn/index.php',      // 网站如果未开启伪静态填写这个，并将上面注释掉。将域名换成你的
    token: '2323333339',                                // 需要和后台填写的保持一致
    shareTitle: 'Joe的博客'                             // 小程序分享标题后缀
};
