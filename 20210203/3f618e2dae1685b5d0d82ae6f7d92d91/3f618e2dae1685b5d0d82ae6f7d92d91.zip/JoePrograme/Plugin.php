<div class="j-setting-contain">
    <link href="<?php echo Helper::options()->rootUrl ?>/usr/plugins/JoePrograme/assets/css/joe.setting.min.css" rel="stylesheet" type="text/css" />
    <div>
        <div class="j-aside">
            <div class="logo">Joe 1.0.2</div>
            <ul class="j-setting-tab">
                <li data-current="j-setting-notice">插件公告</li>
                <li data-current="j-setting-global">插件设置</li>
            </ul>
        </div>
    </div>
    <span id="j-version" style="display: none;">1.0.2</span>
    <div class="j-setting-notice">请求数据中...</div>
    <script src="<?php echo Helper::options()->rootUrl ?>/usr/plugins/JoePrograme/assets/js/joe.setting.min.js"></script>
    <?php

    /**
     * Typecho-Joe-Theme 专用小程序
     * 
     * @package JoePrograme
     * @author Joe
     * @version 1.0.2
     * @link //ae.js.cn
     *
     */

    class JoePrograme_Plugin implements Typecho_Plugin_Interface
    {
        public static function activate()
        {
            Helper::addRoute('jsonp', '/api/[type]', 'JoePrograme_Action');
            Helper::addAction('json', 'JoePrograme_Action');
        }

        public static function deactivate()
        {
            Helper::removeRoute('jsonp');
            Helper::removeAction('json');
        }

        public static function config(Typecho_Widget_Helper_Form $form)
        {
            $JToken = new Typecho_Widget_Helper_Form_Element_Text(
                'JToken',
                NULL,
                Null,
                '请填写接口Token（必填）',
                '介绍：设置Token是为了防止恶意调用暴露出去的接口 <br />
                 格式：英文+数字，格式与内容随意。填写后，小程序那里需要填写这个Token'
            );
            $JToken->setAttribute('class', 'j-setting-content j-setting-global');
            $form->addInput($JToken);

            $JSwiper = new Typecho_Widget_Helper_Form_Element_Text(
                'JSwiper',
                NULL,
                Null,
                '轮播图CID（非必填）',
                '介绍：用于展示在小程序首页顶部的轮播大图 <br />
                 格式：请填写CID，多个使用 || 分隔。<br />
                 例如: 1 || 2 <br />
                 注意：如果您填写错误，或者未查寻到文章，将显示默认图'
            );
            $JSwiper->setAttribute('class', 'j-setting-content j-setting-global');
            $form->addInput($JSwiper);

            $JSwiperNull = new Typecho_Widget_Helper_Form_Element_Text(
                'JSwiperNull',
                NULL,
                Null,
                '轮播图未查询到的默认图（非必填）',
                '介绍：此项用于上方CID未查询到时显示的默认图 <br />
                 格式：https 的图片地址，务必使https，否则不显示！ <br />
                 其他：如果你不想使用上方的CID文章作为轮播图，想使用自定义图片作为轮播图，你可以将上方不填写，直接填写此项即可'
            );
            $JSwiperNull->setAttribute('class', 'j-setting-content j-setting-global');
            $form->addInput($JSwiperNull);

            $JNotice = new Typecho_Widget_Helper_Form_Element_Text(
                'JNotice',
                NULL,
                Null,
                '通知公告内容（非必填）',
                '介绍：用于显示在小程序首页的通知公告 <br />
                 格式：通知内容 || 文章CID（非必填） <br />
                 注意：如果你不想填写文章的CID，那么直接填写通知内容即可'
            );
            $JNotice->setAttribute('class', 'j-setting-content j-setting-global');
            $form->addInput($JNotice);

            $JHotNumer = new Typecho_Widget_Helper_Form_Element_Select(
                'JHotNumer',
                array(
                    '4' => '4篇（默认）',
                    '5' => '5篇',
                    '6' => '6篇',
                    '7' => '7篇',
                    '8' => '8篇',
                    '9' => '9篇',
                    '10' => '10篇',
                ),
                'off',
                '选择需要显示几篇热门文章',
                '介绍：选择需要显示几篇热门文章'
            );
            $JHotNumer->setAttribute('class', 'j-setting-content j-setting-global');
            $form->addInput($JHotNumer->multiMode());

            $JCommentStatus = new Typecho_Widget_Helper_Form_Element_Select(
                'JCommentStatus',
                array(
                    'off' => '关闭（默认）',
                    'on' => '开启（审核时务必关闭！！！否则审核不通过）',
                ),
                'off',
                '是否开启页面评论列表',
                '介绍：小程序审核时务必关闭！！！否则审核无法通过！！！'
            );
            $JCommentStatus->setAttribute('class', 'j-setting-content j-setting-global');
            $form->addInput($JCommentStatus->multiMode());
        }

        public static function personalConfig(Typecho_Widget_Helper_Form $form)
        {
        }

        public static function render()
        {
        }
    }
    ?>